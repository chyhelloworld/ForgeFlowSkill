---
name: ff-deliver
description: 汇总 ForgeFlow 当前版本有效证据、偏差与用户验收入口，按仓库流程交 PR 或交接；不承担实现或独立审核，不自动合并部署。
metadata:
  version: "0.6.1"
---
# ff-deliver 0.6.1

消费有效规格/计划、实际交付版本、实现证据与 plan / goal-mainflow / code 的独立审核结论。缺证据或审核失效交相应职责补齐，不在本技能里自写自审。参考 [交接与接受](references/handoff.md)。

交付短摘要：原需求与本轮变化；明确版本/hash；用户可访问入口和最少操作；已证结果、偏差与未证范围；三类审核及计量限制；需要用户决定的具体事项。证据不全可交接部分成果，但不宣称整体通过。文件路径须接收者实际可读，跨环境传输核实可用。

技术测试通过、技术可交付、真实用户接受、技能 simulated-context-behavior 评估、native-host-integration 分别报告。用户未反馈就是待接受，不能用模型模拟/自评分/截图代签。接受绑定版本、来源与范围；变更后仅沿用仍适用的范围，不将接受扩为发布授权。

PR 是条件动作：仓库确实采用 PR 流程且用户授权创建/更新时，准备当前工作分支的证据与差异后按规则创建/更新，默认 draft。没有 PR 流程或仅交文件时直接交付对应产物；不要求项目开始就建 PR。工作分支提交需现有授权；技能不自动合并主分支、不发布部署、不增加付费或持久权限。审批要求始终服从实际宿主与用户权限。

停止/暂停只留已授权载体的短交接，不追改冻结产品；恢复交 ff-intake 对账真实状态。Mode 0 可当前对话交接，不借交付保存完整讨论记录。

用户交付由本技能负责；暂停或换会话的执行状态压缩交 ff-handoff，接收者先 ff-intake 核实。两者引用同一规格/计划/证据，不重复建库；Mode 0 仅当前对话。

## OpenSpec 与 FF 有效性

遵循 [规格生命周期契约](references/spec-lifecycle.md)。所有 FF 子命令均通过项目本地 `node tools/openspec/ff-spec.mjs` 运行，工作目录为目标项目根；工具不在此相对位置时使用其真实路径，不回退到全局官方 CLI。仅允许 `init --tools none`，不刷新官方工具集成，`update` 拒绝；包名 `@forgeflow/ff-spec`、用户配置/数据命名空间 `ff-spec` 与官方入口分开，项目 `openspec/` 树仍兼容，这不是文件系统安全边界。现行规格只在 openspec/specs；活动 changes 保存差异和回执，Git 保存历史。按稳定 artifact ID、明确路径、排序内容指纹与依赖指纹判断有效性；review 必须绑定目标版本/内容及依赖。文件存在、任务勾选或旧审核均不自动代表 ready。status / instructions apply / validate / archive 共用 FF evaluator；apply 是实施指导，archive 正常路径同步规格并保存历史。不得继续写旧 spec-state.json，不自动导入旧接受或伪造 pass；取消/拒绝只能走显式 disposition+原因+决议引用的关闭路径，保留失败/未完成记录且不合入规格、不制造 pass。三类独立审核、真实主流程、CRAP ≤50（目标约10）、按需 Diagnose/TDD/Handoff 和既有权限边界保持不变。
