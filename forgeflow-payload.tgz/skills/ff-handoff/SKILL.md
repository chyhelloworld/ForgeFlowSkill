---
name: ff-handoff
description: 在暂停或换会话时准备最小项目内交出检查点，供接收方经 Intake 核实后续做；不是交付验收或自动启动任务。
metadata:
  version: "0.9.2-goal.2"
---
# ff-handoff 0.9.2-goal.2

只在暂停、上下文切换、交给另一执行者或用户明确要求时使用；不是每个阶段必做。与 ff-deliver 的用户交付不同，本技能输出可续做的短检查点；接收方入口始终 ff-intake。

读 [交出检查点](references/checkpoint.md)。先核对可见的真实工作状态，把已确认目标、当前版本、未完成切片、风险与下一步指向项目已有规格/唯一计划/证据。只补交接必需的瞬时状态，不复制第二份计划、规格或完整聊天。

仅使用已授权项目内载体：优先更新既有交接位置或引用现有任务，必要新文件须处于授权范围且接收者可访问；禁止默认写全局临时目录。记录模式0时只在当前对话交接，不保存持久化记录；模式1/2沿用既有授权和位置，交接本身仍是短摘要，不能借此抄完整讨论或模型私有推理。写入成功且验证路径后才声称已保存；跨环境文件必须先核实接收者实际访问能力，未核实标待传输。

交出不自动开新会话、派生代理、启动后台任务、重跑命令、reset/stash/提交工作区或保证后续自动唤醒。权限依据必须引用真实用户确认，工具/平台门禁仍有效；检查点文本不能授予或扩大权限。接收者通过 ff-intake 重新核对实际目标、工作区、进程与证据有效性，再由相应职责更新唯一计划和执行，不能盲信“已完成/可继续”。

## OpenSpec 与 FF 有效性

遵循 [规格生命周期契约](references/spec-lifecycle.md)。所有 FF 子命令均通过项目本地 `node tools/openspec/ff-spec.mjs` 运行，工作目录为目标项目根；工具不在此相对位置时使用其真实路径，不回退到全局官方 CLI。仅允许 `init --tools none`，不刷新官方工具集成，`update` 拒绝；包名 `@forgeflow/ff-spec`、用户配置/数据命名空间 `ff-spec` 与官方入口分开，项目 `openspec/` 树仍兼容，这不是文件系统安全边界。现行规格只在 openspec/specs；活动 changes 保存差异和回执，Git 保存历史。按稳定 artifact ID、明确路径、排序内容指纹与依赖指纹判断有效性；review 必须绑定目标版本/内容及依赖。文件存在、任务勾选或旧审核均不自动代表 ready。status / instructions apply / validate / archive 共用 FF evaluator；apply 是实施指导，archive 正常路径同步规格并保存历史。不得继续写旧 spec-state.json，不自动导入旧接受或伪造 pass；取消/拒绝只能走显式 disposition+原因+决议引用的关闭路径，保留失败/未完成记录且不合入规格、不制造 pass。三类独立审核、真实主流程、CRAP ≤50（目标约10）、按需 Diagnose/TDD/Handoff 和既有权限边界保持不变。

## 跨会话决策恢复（按需）

跨会话或复杂取舍容易丢失原始目标时，按 [决策索引契约](references/decision-index.md) 使用同一权威记录的轻索引。简单任务跳过；不新增技能、状态库或授权。沿用记录模式与保存授权，不自动落盘。

## Codex 原生目标（条件启用）

宿主提供本聊天原生目标或用户显式要求结合 `/goal` 时，读取 [目标桥接契约](references/goal-bridge.md)。交接只指向同一规格/唯一计划与原回执；原生状态/预算不可见标 unknown，Mode 0 仅当前对话。新上下文先 Intake 核实最新目标、项目与实际依赖，再给 resume 传当前确认的 `--current-goal`，不能照抄旧 checkpoint。目标修订不匹配会先全局 INSPECT，调用者随后核对影响与适用性，只实际复做受影响工作；不改签旧回执，不盲续 running/unknown，不承诺 exactly-once 或自动唤醒。未触发时保持普通 FF。

## 变更与恢复边界

按需运行本skill scripts/resume.py读取检查点并比对显式最新目标修订号、真实依赖hash与完成回执；读取[恢复检查约定](references/resume.md)。CHECKPOINT_CURRENT不是最终完成或批准；SKIP_COMPLETED只对当前已证动作有效，INSPECT时先核查，不自动重跑副作用。检查点是权威文档的索引，不复制成第二计划。
