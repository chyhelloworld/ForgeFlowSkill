# 来源与许可

ff-research 是 ForgeFlow 的中文改编，不是 Matt 官方技能。来源：[Matt research](https://github.com/mattpocock/skills/blob/49dd158d1076134a641b33efb035946536778336/skills/engineering/research/SKILL.md)，固定提交 49dd158d1076134a641b33efb035946536778336。原版 MIT 许可与版权见 [LICENSE-MATT](LICENSE-MATT)。

FF 改编增加范围/授权边界、版本化证据、停止条件及禁止伪造结果；不继承原文涉及自动扩权限、全局修改或无限采访的建议。FF 基线未另附公开许可证，不为其追授许可。研究与写作不变成强制开发流水线。

实验2新增跨会话决策索引参考 Matt Pocock `skills/engineering/wayfinder`，提交 `49dd158d1076134a641b33efb035946536778336`，MIT（LICENSE-MATT）。FF 重新约束为可选索引，不继承 tracker/push 或执行例外。
