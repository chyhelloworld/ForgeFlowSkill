---
name: ff-implement
description: 执行已获准且计划有效的 ForgeFlow 纵向切片，修复与验证主要业务流程；不代替独立审核或宣布用户接受。
metadata:
  version: "0.7.0"
---
# ff-implement 0.7.0

读取最新确认目标、有效规格与唯一计划、独立计划审核结论、真实工作区和项目命令。有效资料直接复用，不重复 Grill/Design/Prove。缺规格/过期任务分别交 ff-spec / ff-plan；计划审核未满足时先交 ff-review 的 plan 审核，不把 ready 当权限。没有独立上下文时明确披露，不能伪称审核通过。

开始/恢复先读 [接手、恢复与变更](references/continuity.md)。核对含未提交/未跟踪内容的实际状态，保护他人改动，只执行剩余或受影响的获准切片；旧命令不可观察就标未知，不重复可能写入的操作。

实现与验证读 [证据与回归](references/evidence.md)。在大规模依赖验收的扩展前做最小入口/证据可行性预检。测试聚焦主要业务流程与变化影响，不追求函数、字段、异常穷举或覆盖率数字；真实数据丢失/权限/已知缺陷才加必要专项。修复采用可复现的短反馈；适用 TDD 时保留真实 red→green，不能编造失败。

UI 按已选设计和目标平台检查最终真实渲染与操作；截图存在不等于已查看，Linux 通过不证明 Windows。技术未知交 Prove，视觉选择失效交 Design，只重开受影响部分。

同步唯一任务的实际进度和证据，不自建第二份计划。每次变化追踪受影响规格/票/测试/审核/用户接受，旧绿灯不覆盖新版本；目标或依赖改变先修相应规格/计划并复核计划。范围内日常开发、测试、文档和已获准工作分支提交无需重复询问；主分支合并、部署、付费、持久访问和安全敏感动作不由本技能授权。

输出可审 diff/快照、真实测试日志与未证项给 ff-review；发现回到实现者修复后独立复核。完成实现不等于技术验收、用户接受或发布。小修仍可内联规格/单条任务/短审查，不强制十二技能全跑。

遇实际故障/性能回归按需调用 ff-diagnose，适用测试驱动时调用 ff-tdd；二者提供方法与证据，不新增必经阶段或替代当前实现责任。暂停/换会话按需 ff-handoff 准备短检查点，恢复仍先 ff-intake。

## OpenSpec 与 FF 有效性

遵循 [规格生命周期契约](references/spec-lifecycle.md)。所有 FF 子命令均通过项目本地 `node tools/openspec/ff-spec.mjs` 运行，工作目录为目标项目根；工具不在此相对位置时使用其真实路径，不回退到全局官方 CLI。仅允许 `init --tools none`，不刷新官方工具集成，`update` 拒绝；包名 `@forgeflow/ff-spec`、用户配置/数据命名空间 `ff-spec` 与官方入口分开，项目 `openspec/` 树仍兼容，这不是文件系统安全边界。现行规格只在 openspec/specs；活动 changes 保存差异和回执，Git 保存历史。按稳定 artifact ID、明确路径、排序内容指纹与依赖指纹判断有效性；review 必须绑定目标版本/内容及依赖。文件存在、任务勾选或旧审核均不自动代表 ready。status / instructions apply / validate / archive 共用 FF evaluator；apply 是实施指导，archive 正常路径同步规格并保存历史。不得继续写旧 spec-state.json，不自动导入旧接受或伪造 pass；取消/拒绝只能走显式 disposition+原因+决议引用的关闭路径，保留失败/未完成记录且不合入规格、不制造 pass。三类独立审核、真实主流程、CRAP ≤50（目标约10）、按需 Diagnose/TDD/Handoff 和既有权限边界保持不变。
