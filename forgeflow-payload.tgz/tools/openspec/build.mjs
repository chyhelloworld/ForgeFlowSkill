#!/usr/bin/env node
/** Rebuild the pinned upstream TypeScript plus the reviewed FF source patch. */
import { runtimeHashes, dependencyHashes } from './ff-build.mjs';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, lstatSync, unlinkSync, rmdirSync, mkdirSync, cpSync, existsSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const home = path.dirname(fileURLToPath(import.meta.url));
const build = path.join(home, '.build');
const bootstrap = path.join(home, '.bootstrap');
const pin = JSON.parse(readFileSync(path.join(home, 'upstream.json'), 'utf8'));
function run(command, args, cwd = home, env = {}) {
  const result = spawnSync(command, args, { cwd, stdio: 'inherit', env: { ...process.env, ...env }, shell: false });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`${command} failed (${result.status})`);
}
function verify(name, expected) {
  const actual = createHash('sha256').update(readFileSync(path.join(home, name))).digest('hex');
  if (actual !== expected) throw new Error(`Integrity mismatch: ${name}`);
}
function npm(args) {
  // npm is a .cmd shim on Windows; invoke its official JS entry via node.
  const found = process.env.npm_execpath;
  if (found && /npm-cli\.js$/.test(found)) return run(process.execPath, [found, ...args]);
  if (process.platform === 'win32') {
    const cli = path.join(path.dirname(process.execPath), 'node_modules/npm/bin/npm-cli.js');
    if (!existsSync(cli)) throw new Error('Run via npm exec -- node tools/openspec/build.mjs so npm_execpath is available.');
    return run(process.execPath, [cli, ...args]);
  }
  run('npm', args);
}
function sourceVersionArg(argv) {
  if (argv.includes('--source-version')) throw new Error('--source-version requires a value');
  const flag = argv.find(arg => arg.startsWith('--source-version='));
  if (!flag) return undefined;
  const value = flag.slice('--source-version='.length);
  if (!value) throw new Error('--source-version requires a value');
  return value;
}
function main(explicitVersion) {
  // Validate the stamp before the expensive, network-bound build so a typo cannot
  // leave a finished .build that a rerun then refuses to overwrite.
  const [major, minor] = process.versions.node.split('.').map(Number);
  if (major < 20 || (major === 20 && minor < 19)) throw new Error('Node >=20.19 required');
  verify(pin.archive, pin.archiveSha256);
  verify(pin.patch, pin.patchSha256);
  for (const [name, hash] of Object.entries(pin.bootstrapSha256)) verify(name, hash);
  if (existsSync(build)) throw new Error('.build already exists; inspect it, then rerun with --clean to rebuild.');
  mkdirSync(build, { recursive: true });
  mkdirSync(bootstrap, { recursive: true });
  cpSync(path.join(home, 'bootstrap/package.json'), path.join(bootstrap, 'package.json'));
  cpSync(path.join(home, 'bootstrap/package-lock.json'), path.join(bootstrap, 'package-lock.json'));
  // GNU tar interprets E: as a remote host. The archive is a verified sibling;
  // keep its name relative to cwd for GNU tar, bsdtar and Git Bash alike.
  run('tar', ['-xzf', pin.archive, '-C', '.build']);
  run('git', ['apply', '--check', path.join(home, pin.patch)], build, { GIT_CEILING_DIRECTORIES: home });
  run('git', ['apply', path.join(home, pin.patch)], build, { GIT_CEILING_DIRECTORIES: home });
  if (!existsSync(path.join(build, 'src/core/ff-validity.ts'))) throw new Error('FF source patch was not applied');
  npm(['ci', '--prefix', bootstrap, '--ignore-scripts', '--cache', path.join(bootstrap, 'cache')]);
  const pnpm = path.join(bootstrap, 'node_modules/pnpm/bin/pnpm.cjs');
  run(process.execPath, [pnpm, 'install', '--frozen-lockfile', '--ignore-scripts',
    ...(process.platform === 'win32' ? ['--node-linker=hoisted'] : []),
    '--store-dir', path.join(bootstrap, 'store')], build, {
    XDG_DATA_HOME: path.join(bootstrap, 'data'), XDG_CACHE_HOME: path.join(bootstrap, 'cache'),
  });
  run(process.execPath, ['build.js'], build);
  // The CLI reports its own package.json version, and the patch freezes a trial pin there.
  // Stamp the FF source version so doctor can compare skills, state and CLI without a false drift.
  // A checkout always has the FF package.json two levels up; a copied fixture may not.
  const sourcePackage = path.join(home, '../../package.json');
  const sourceVersion = explicitVersion ?? (existsSync(sourcePackage) ? JSON.parse(readFileSync(sourcePackage, 'utf8')).version : undefined);
  if (sourceVersion) {
    const builtManifest = path.join(build, 'package.json');
    const manifest = JSON.parse(readFileSync(builtManifest, 'utf8'));
    manifest.version = sourceVersion;
    writeFileSync(builtManifest, JSON.stringify(manifest, null, 2) + '\n');
  }
  writeFileSync(path.join(build, 'FF-BUILD.json'), JSON.stringify({ ...pin, ...(sourceVersion ? { sourceVersion } : {}), runtimeHashes: runtimeHashes(build), dependencyHashes: dependencyHashes(build), platform: process.platform, arch: process.arch, node: process.version, builtAt: new Date().toISOString() }, null, 2) + '\n');
  console.log(`Built project-local CLI: ${path.join(home, 'ff-spec.mjs')}`);
}
// --clean owns only the fixed sibling .build; existing .bootstrap data is retained.
function cleanBuild() {
  function removeGenerated(file) {
    const entry = lstatSync(file, { throwIfNoEntry: false });
    if (!entry) return;
    if (entry.isSymbolicLink() || entry.isFile()) unlinkSync(file);
    else if (entry.isDirectory()) {
      for (const name of readdirSync(file)) removeGenerated(path.join(file, name));
      rmdirSync(file);
    } else throw new Error('Unexpected .build entry');
  }
  removeGenerated(build);
  if (lstatSync(build, { throwIfNoEntry: false })) throw new Error('.build cleanup incomplete');
}
try {
  // Parse before --clean: a malformed stamp must not delete an existing .build.
  const explicitVersion = sourceVersionArg(process.argv);
  if (process.argv.includes('--clean')) cleanBuild();
  main(explicitVersion);
} catch (error) { console.error(error.message); process.exitCode = 1; }
