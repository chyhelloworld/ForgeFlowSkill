# 最小原生验证与证据继承（2026-10-19）

这是 `96f020149cd355f00e69fbea50c0454b619048ce` 视觉审查规则修正的补测与文档收尾，不是 R5、完整产品重做或主干合并。实测包 manifest 为 `2d53e876fa90997c8fe14b7fc56173661758a1a4288bb9d8f019e3ba85cb3c26`，payload 为 `5b43c3046718f09c6eb1467f3212be4f8251cd5b061015cdacc5588d5aa52549`。此报告加入后的包仅更新迭代文档；最终包哈希、逐文件差异及安装回执另存交付记录，不能改签实测包。

## 标准与真实缺口

依据 [维护约定](../../docs/maintainers/development.md)、[证据分类](../../evaluations/README.md)、[Goal契约](../../docs/maintainers/CODEX-GOAL-BRIDGE.md) 与 [历史设计](../../planning/codex-goal-adaptation-design.md) 核对，并由独立代理复核。历史 G01–G12 表明确为未来验收计划，不是“本次同轮全部 native PASS”的条款。当前规则要求重做受影响验证，不要求重跑全部未变场景。R4拒绝必须保留，不能扩为所有FF机制修订的审美通行证。

| 场景 | 已有事实与本次处理 |
| --- | --- |
| G01 / G11 技能、项目主流程 | 历史实际安装/自动写产品不是新指南加载证据。本次补足最终项目安装版实际发现、读取和条件引用；完整产品/跨聊天全场景不据此通过。 |
| G02 讨论/采纳；G03仅设计 | 历史保护文件观察及本轮新上下文回放可按原范围保留，未改语义；不是完整 native 采纳链实测，不升级结论。 |
| G04历史诱饵/错项目 | 原生完整场景未证；本次隔离根与精确安装路径只覆盖当前加载风险。 |
| G05中断/缺回执 | 历史真实中断、新上下文检查记录继承为有界观察，恢复实现未改；不声称即时强杀或 exactly-once，不重做产品副作用。 |
| G06 R1→R2适用性 | 契约/回放保留；本次 ready marker 不是目标语义修订或副作用适用性实验，完整 native 场景仍未据此证明。 |
| G07预算/暂停/恢复 | 旧预算转态与暂停后当前回合迟收尾已有观察；旧R2为手动回合，不能证明自动恢复。本次真实补测 paused→active 自动续读。 |
| G08内层工具失败 | 原失败不被外层exit0覆盖。本次夹具错误路径真实failed/1，助手准确披露且读取正确引用；保留失败与修正。 |
| G09完成/接受 | 本次真实观测审计Goal complete，FF仍报合成产物REJECTED及视觉证据不足；不代替真人产品验收。 |
| G10工程/计量 | 旧产品同版计量不归新产品版本。本次未改FF生产函数，生产函数CRAP为有理由N/A；一次性native驱动未测复杂度/同版覆盖率，标NOT_MEASURED，不称全代码通过。 |
| G12无接口/Mode 0 | 未改fallback；本次有接口实验不能证明无接口场景，保留未测。 |

## 本次真实执行

证据位于外层FF项目 `_verification/092-native-close-20261019/`。使用现有 `codex-cli 0.163.0-alpha.10.2`，后端exe SHA256 `9ecb9df2ecafcc00542ef0966c6f1737a81397dc9531b0a4b178238e2bf4a46d`。不改模型/账号/全局配置/安全设置、不读私有sessions、不复制凭证；新建自有只读审计线程，记录实际默认模型/权限与事件。只保存选定公开协议、命令状态、stdout长度/哈希及助手可见回复，丢弃reasoning和原始stderr，不冒充完整原始轨迹。

项目为 `_verification/092-goal2-visual-20261019/real-install-full`，native `skills/list` 同时可见项目候选和用户稳定版；实际命令读取该项目候选的四个关键文件及所需引用，并读取fixture，未读取用户稳定版。关键文件为`ff-review/SKILL.md`、`ff-review/references/visual-review.md`、`ff-deliver/SKILL.md`、`ff-deliver/references/goal-bridge.md`。成功stdout哈希均精确等于对应安装文件字节加PowerShell末尾CRLF。两SKILL按现有安装器改写项目CLI路径并附manifest绑定，两个引用与源码逐字节相同；不能误要求SKILL原始字节不变。

| 执行 | 实际结果 |
| --- | --- |
| 首轮，2自动回合/180秒上限 | 等首回合结束才暂停，runner已起第二回合；未等在途回合收尾便恢复，第三回合触发驱动上限。保留失败；同一保护再次干扰teardown，原最终查询缺失。后续独立公开API查询确认自有目标paused，不能反写成首轮完整清理通过。 |
| v2，4自动回合/210秒上限 | 在WAITING后暂停，等待在途回合收尾，连续3秒无新启动；root只改fixture ready，active后自动重读。3自动回合、0客户端turn/start。实际读取当前指南与正确bridge；夹具误写codex-goal-bridge.md导致failed/1。最终native仍active，明确披露缺文件与合成拒绝，清理查询paused。runCompleted只代表驱动结束。 |
| v3，仅修正确路径的完成测试，2自动回合/150秒上限 | 1自动回合、0客户端turn/start、12命令exit0。03:49:49.954774 UTC收到原生complete更新，随后goal/get实际返回complete；客户端从未发送complete。原生账面29,590/60,000 tokens、75秒是该次查询值，不是全线程最终计费或驱动墙钟（95.954秒）。最终FF四轴说明技术证据仅夹具算术记录，视觉/完整动态/参考不足，合成产物仍REJECTED，没有真人接受。仅审计任务完成。清理再次paused、interrupt在途回合并查询确认；最后turn事件为interrupted，不能写“成功完成1个turn”或宣称当前Goal仍complete。 |

v2错误是测试指令的路径笔误，不是发布包漏文件；原错误读取、助手披露、正确引用读取和v3修正均保留。fixture是合成测试干系人的拒绝标记，不伪装真实产品反馈。v3明确提示区分拒绝与审计完成，是一次真实集成观察，不是盲评或模型普遍遵守保证。根驱动更新ready与模型实际重读分别记录；没有产品写入、下载图片或R5实施。

## 继承而非本轮重跑

记忆书架项目公开的 `.experiment/evidence/native-goal/automatic-budget-probe.json`、validation/result及`product-auto-evidence.json`重新核SHA并匹配其index。历史后端身份来自FF `_handoff/20261017/global-setup/goal/desktop-backend-goal.json`，与本次exe同哈希，因此可保留该二进制下原观察；不据此保证远端服务、所有宿主或未来行为相同。

旧预算1的真实自动回合后进入budgetLimited，账面tokensUsed=16,588，活连接后续30.453秒无新回合；简单任务已结束等因素也可能导致安静，不能独占归因为预算调度。旧产品paused后同一回合继续到检查点，证明暂停不等于立即杀进程。它们不是逐token硬截断、全局预算或所有情况下停止的证明；本轮未重复这些实验。此前回归、技能格式与安装套件也按README列出的原版本/命令回执继承，未改生产函数和测试入口，不冒称本轮再执行。

关键原始记录SHA256：

- 首轮native-run：`41ff4dfb67048cae31c893c2d341b459bfd0f79eff0b047c00655bc0666ca4c2`。
- v2 native-run：`2e69a75a8b40739ec501cc4f2a25fd654046997865883a024ebcc1a0848f32bd`。
- v3 native-run：`a5ecc6e96debc64b547f4b508e29ed3081fc318cced9882cc527d7f91c8400db`。
- 独立清理查询：`9bd44566d3e29698cb65e29a448579f851d5e64867824e14fd1f18ef900df0fd`。

## 当前结论与权限

本次受影响的安装加载、条件引用、自动恢复与“原生审计完成不反转产物拒绝”已取得有界真实证据；预算仅继承旧观察。上述范围不再有待补的native技术阻塞，也不构成G01–G12全通过或整个0.9.2全面验收。R4视觉核心拒绝继续有效，产品不因FF机制修正而获接受。

当前用户明确禁止合并、推送、全局安装、发布部署，本次仅维护报告、重打文档包并提交工作分支。不需要凭空要求一次笼统“真人晋级确认”才能提交修正；若后续要执行合并等动作，须先取得该具体动作授权。产品下一步仍需单独的实际动效小样与接受证据，不属于本次技术收尾。
