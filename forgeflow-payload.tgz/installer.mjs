#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkedRoot, safe, fail } from './tools/installer/files.mjs';
import { install, doctor, removeHost, updateSkill } from './tools/installer/install.mjs';
import { normalizeHosts, hosts } from './tools/installer/state.mjs';
import { control, recover, rollback, loadState } from './tools/installer/transaction.mjs';
export function parse(args) {
  const options = { command: args.shift() };
  if (!['install', 'update-skill', 'doctor', 'remove-host', 'rollback', 'recover'].includes(options.command)) fail('Usage: node installer.mjs install|update-skill|doctor|remove-host|rollback|recover --project PATH [--host codex|claude|dsh | --hosts codex,claude,dsh] [--mode full|skills-only --build]');
  while (args.length) {
    const key = args.shift();
    if (key === '--build' && !options.build) { options.build = true; continue; }
    if (!['--project', '--host', '--hosts', '--mode', '--reuse-build', '--skill'].includes(key) || options[key.slice(2)] || !args.length) fail('Invalid or duplicate argument');
    options[key.slice(2)] = args.shift();
  }
  if (options.command === 'update-skill' && (!options.skill || options.host || options.hosts)) fail('update-skill requires --skill and updates all installed hosts; no host flags');
  if (options.command !== 'update-skill' && options.skill) fail('--skill applies only to update-skill');
  if (!options.project) fail('--project is required');
  if (options.host && !hosts.includes(options.host)) fail('Unknown host');
  if (options.host && options.hosts) fail('--host conflicts with --hosts');
  if (options.hosts) {
    options.hosts = normalizeHosts(options.hosts.split(','));
    if (options.hosts.length < 2) fail('--hosts requires at least two hosts (codex,claude,dsh)');
  }
  if (options.command === 'install' && (!(options.host || options.hosts) || !['full', 'skills-only'].includes(options.mode))) fail('Explicit --host or --hosts and --mode full|skills-only required');
  if (options.command !== 'install' && (options.hosts || options.mode || options.build || options['reuse-build'])) fail('Install flags apply only to install');
  if (['rollback', 'recover'].includes(options.command) && options.host) fail('--host applies only to install, doctor or remove-host');
  if (options.command === 'remove-host' && !options.host) fail('remove-host requires --host codex|claude|dsh');
  if (options.mode === 'skills-only' && options.build) fail('--build conflicts with skills-only');
  if (options['reuse-build'] && (options.build || options.mode !== 'full')) fail('--reuse-build requires full and conflicts with --build');
  return options;
}
export function main(args) {
  const options = parse([...args]);
  const project = checkedRoot(options.project);
  const source = checkedRoot(path.dirname(fileURLToPath(import.meta.url)));
  const lock = safe(project, `${control}/lock`);
  if (options.command === 'doctor') return doctor(project, options.host);
  fs.mkdirSync(path.dirname(lock), { recursive: true });
  if (options.command === 'recover') {
    if (fs.existsSync(lock)) fail('Lock exists: verify no installer is running, then manually remove only the empty .forgeflow/install/lock directory before recover');
  }
  try { fs.mkdirSync(lock); } catch (e) { if (e.code === 'EEXIST') fail('Installation locked; do not run concurrently'); throw e; }
  try {
    if (options.command === 'recover') return recover(project);
    if (fs.existsSync(safe(project, `${control}/pending.json`))) fail('Pending transaction; run recover first');
    if (options.command === 'rollback') return { status: 'ROLLED_BACK', version: rollback(project, loadState(project)).version };
    if (options.command === 'remove-host') return removeHost(project, options.host);
    if (options.command === 'update-skill') return updateSkill(project, source, options);
    return install(project, source, options);
  } finally { fs.rmdirSync(lock); }
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { console.log(JSON.stringify(main(process.argv.slice(2)), null, 2)); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
}
