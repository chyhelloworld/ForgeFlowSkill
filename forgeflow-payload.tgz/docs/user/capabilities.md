# 具体能力与使用场景

0.9.1 工作分支候选，17 项技能。先按缺口选择职责，不要求跑完全部技能。安装见 [安装入口](install.md)，完整流程与图见 [中文手册](../FF-中文使用手册.md)。

## 具体能做什么

FF 帮助 AI 执行者沿同一份需求和项目事实工作：澄清目标、写行为与验收规格、探索设计或验证未知、拆小任务、实现、独立审核，再整理交付或交接。已有资料有效时直接复用，小修不必补一整套文档。研究、复盘和写作也可以单独使用。

| 版本增量 | 什么时候用 | 具体功能与输出 | 使用入口 |
| --- | --- | --- | --- |
| **0.7：阶段审核与证据摘要** | 想知道当前做到了哪一步、缺什么证据，而不只看“任务已勾选” | 要求把必须交付项、预期价值、证据与假设分开；以核心目标/主要流程、计划、代码三类审核给出短结论、风险、缺口和下一步。可选工具核对已导出的审核/证据索引，输出 `RECORDED`、`GAPS` 或 `INVALID`；缺同版复杂度/覆盖率时标 `NOT_MEASURED` | `ff-grill`、`ff-spec`、`ff-prove`、`ff-review`、`ff-deliver`；可选 `ff-review/scripts/health.py` |
| **0.8：变更范围与中断恢复** | 中途提新想法、明确改需求，或换会话后继续 | 在既有规则上补强：讨论不自动入计划，明确批准后只更新受影响规格/任务/测试/依赖；区分现行、活动和历史资料。恢复工具检查当前目标、依赖哈希和完成回执，逐动作输出 `SKIP_COMPLETED`、`VERIFY_CURRENT_AUTHORITY` 或 `INSPECT` | `ff-spec`、`ff-plan`、`ff-intake`、`ff-handoff`；新增可选 `ff-handoff/scripts/resume.py` |
| **0.9：完整旅程与同版交互证据** | 做界面设计、验证一条主要用户路径，或检查设计与实现是否对得上 | 实现前先写视觉方向、从入口到结果的主要步骤和关键返回/失败状态；预期与实测分开。工具核对当前设计/源码、步骤 ID/顺序/状态连续性、操作轨迹和 UI 截图引用，输出 `OBSERVED`、`GAPS` 或 `INVALID` | `ff-design`、`ff-review`；新增可选 `ff-design/scripts/journey.py` |

这三版没有增加技能数量或另建计划数据库。上表的流程要求写在技能提示词中，由执行者遵守；Python 工具只自动核对所列记录，不负责决定需求、执行恢复或操作浏览器。它们不是新的 `ff-spec health/resume/journey` 子命令。

0.9.1 已纳入经用户批准的最小候选：Health 复用同包 Resume 的 Windows 证据路径边界、显式 UTF-8 输入与缺依赖失败；ff-retro 区分项目与 FF 自身改进，沿用旧版对照/独立审核/待用户晋级，并可形成有条件的资产候选。ff-intake 只读检索项目声明的相关记录。实际范围、失败和未测项见 [0.9.1 记录](../../iterations/0.9.1/README.md)。


## 按使用场景开始

以下是发给已发现 FF 技能的 AI 宿主的自然语言请求，不是 PowerShell 命令，也不保证注册同名斜杠命令。宿主必须能访问项目、运行相应工具，并已有本次操作所需授权。

| 场景 | 可以怎样说 | 应得到什么 |
| --- | --- | --- |
| 新项目 | “请用 ff-grill 明确这个预约工具的用户、首版范围和成功标准，先不要实现；确认后再用 ff-spec 写主要行为与验收。” | 原始目标、取舍和确认状态；确认后形成规格。不会因做完澄清就自动获准写代码 |
| 接手旧项目 | “请用 ff-intake 只读核对当前规格、活动任务、未提交改动和实际测试；保留已有有效结果，指出最小下一步。” | 当前事实、过期/未知项、可继续的切片；不因换人重做整个项目 |
| 中途只讨论想法 | “我们能否加批量导出？先讨论影响，不改代码、规格或任务。” | 候选、影响和待决定项；不把提问当批准 |
| 明确改需求 | “确认加入批量导出。请用 ff-spec、ff-plan 只更新受影响行为、任务、验收和依赖；在现有授权范围内推进。” | 受影响范围和更新后的规格/计划，旧结论保留为历史或失效；不扩展到无关重构 |
| 暂停和恢复 | “暂停前用 ff-handoff 留下检查点；新会话用 ff-intake 核对最新目标、原进程和完成回执，只继续未完成部分。” | 可核对的短交接与逐动作恢复建议，不盲目重跑副作用 |
| 设计与交互核对 | “请用 ff-design 写清从打开页面到完成主要任务的路径、视觉方向和关键状态，先只做设计；获准实现后，用 ff-review 对照真实操作和截图。” | 设计候选/约束、预期路径、实际结果及差异；没有真实操作时明确未验证 |

**0.8 的实际例子**：导出完成后索引进程被真实中断，新上下文接收者核对后保留已完成导出，只继续索引和后续审查。恢复检查器提供判断记录，真正的进程观察与业务命令由执行者完成。

**0.9 的实际例子**：对当时冻结的离线手册执行“打开→筛选→跳转阅读→空筛选→恢复→窄视口打开/筛选/跳转”，保存真实 Chrome 截图和操作轨迹。这是已完成的文档使用旅程实验；当前 HTML 已变动，旧证据按原源码解释，不能算本包交互验收，也不代表任意应用或真实手机验收。


## 第一次在 Codex 中使用

在 Codex 中打开上面安装的**目标项目根目录**；若会话早于安装，重新打开项目或启动新会话，先核对技能是否已发现。可以直接输入：

```text
请用 $ff-intake 只读检查这个项目：核对目标、规格、活动任务、Git 工作区和已有验证，说明当前缺口与建议的下一步，保留现有改动。
```

技能文件存在、Codex 能发现技能、模型实际完成任务是不同的验证层次；不保证自动注册同名斜杠命令。上述本地自检成功（显示 CLI 帮助、退出码 0）只表示 CLI 可运行。安装也不会自动初始化规格、批准计划或执行发布。


## 实际命令入口与前置条件

下面均在**已安装的目标项目根目录**运行。技能文本可单独使用；三个可选 Python 工具另需 **Python 3.9+** 和真实导出的 JSON 记录。命令不会替你采集证据、生成可信回执或取得批准；输入格式见各协议，示例记录不能当实际执行结果。

| 要做什么 | 确实存在的入口 | 输出与边界 |
| --- | --- | --- |
| 检查已安装 CLI 能否启动 | `node .forgeflow/install/doctor.mjs` | full 模式可探测 CLI，skills-only 会 BLOCKED；不是业务或宿主验收 |
| 列出已有变更 | `node .forgeflow/ff-spec.mjs list --json` | 实际项目中的变更列表，不自动创建任务 |
| 查看活动变更有效性 | `node .forgeflow/ff-spec.mjs status --change CHANGE --json` | 产物状态与适用的 FF 规则结果；`CHANGE` 要换成真实活动变更名 |
| 读取实施指导 | `node .forgeflow/ff-spec.mjs instructions apply --change CHANGE --json` | 指导与就绪信息，不执行代码、不表示人类接受 |
| 校验已有变更 | `node .forgeflow/ff-spec.mjs validate CHANGE --strict --json` | 校验发现；配置 FF policy 后按现有规则核对声明的产物/审核有效性，不证明语义正确或授权 |
| 0.7 审核证据摘要 | `python -X utf8 .agents/skills/ff-review/scripts/health.py health-record.json --root .` | `RECORDED` / `GAPS` / `INVALID`；[索引格式](../../skills/ff-review/references/health.md)，不替代三类独立审核或真实计量 |
| 0.8 中断恢复核对 | `python -X utf8 .agents/skills/ff-handoff/scripts/resume.py checkpoint.json --root . --current-goal R2` | `R2` 必须来自当前确认的目标修订；[格式与逐动作状态](../../skills/ff-handoff/references/resume.md)，不检测进程存活、不执行动作、不保证 exactly-once |
| 0.9 主要旅程证据核对 | `python -X utf8 .agents/skills/ff-design/scripts/journey.py journey.json --root . --current-target T1` | `T1` 必须对应当前目标/版本；[记录格式](../../skills/ff-design/references/journey.md)。UI 需操作轨迹与 PNG 引用，CLI 需实际命令/结果轨迹；`OBSERVED` 不等于验收 |

Python 工具的退出码均为 0（声明记录通过本工具核对）、1（有缺口）或 2（格式/读取错误）。没有自动接入 CI、持续监控或拦截其他命令；调用者仍要处理结果。0.9.1 的 Health 已复用同包 Resume 检查 rooted/ADS/junction 路径边界，缺依赖时返回 INVALID；[旧限制记录](../../iterations/0.8/independent-health-legacy-boundary.json)保留历史含义。默认 cp936 的任意 Unicode stdout 仍有限制，按示例用 `python -X utf8`。详见[本版记录](../../iterations/0.9.1/README.md)；这些检查器不是安全或权限边界。

新项目确实需要建立 OpenSpec 目录时，在获准写入后运行 `node .forgeflow/ff-spec.mjs init --tools none`；已有项目先盘点，不重复初始化。当前规格放 `openspec/specs/`，活动变更放 `openspec/changes/`，历史归档不冒充现行承诺。更完整的生命周期、归档与取消/拒绝规则见[生命周期契约](../maintainers/SPEC-LIFECYCLE.md)。


## 新项目怎么开始

1. **明确要解决的问题**：目标或取舍不清时用 `ff-grill`，再用 `ff-spec` 写清主流程、边界与验收标准；目标已明确就直接复用。
2. **解决关键未知**：需要视觉方向时用 `ff-design`，需要验证技术可行性或真实入口时用 `ff-prove`，没有这类缺口可跳过。
3. **按小切片实施**：用 `ff-plan` 拆出可验收任务，经独立 `ff-review` 计划审核后，由 `ff-implement` 在已授权范围内实施和验证。
4. **核验并交付**：按适用范围独立审核真实主流程与代码，由 `ff-deliver` 整理证据、未验证项和人工接受状态。提交、PR、合并和发布按各自授权处理。

示例：`请用 $ff-grill 帮我明确这个新项目的用户、问题、首版范围和验收目标，先不要实现。`


## 旧项目或半成品怎么继续

先用 `ff-intake` 只读对账，核对当前规格、活动变更、任务、代码、测试和未提交改动。按缺口接下一步：需求不清回到 Grill/Spec，缺任务用 Plan，条件有效且已获准则进入 Implement；不重复已经有效的步骤。

故障原因不明时用 `ff-diagnose`；实现中有适合测试驱动的行为时用 `ff-tdd`；暂停或换会话时用 `ff-handoff` 留下短检查点，接收方再用 Intake 核实。

若项目已有旧版 FF/OpenSpec 状态，先读 [迁移说明](../../MIGRATION.md)。现行规格在 `openspec/specs/`，活动变更在 `openspec/changes/`；旧回执不能自动当作新版本的通过证据。项目安装后的 CLI 入口统一为 `node .forgeflow/ff-spec.mjs`。


## 用户主动复盘与 RSI 的边界

可以主动请求 **`ff-retro`**，例如：“请用 ff-retro 复盘 FF 本仓库这轮实际执行中的重复代价，只提出有证据的改进候选，先不要改代码或技能。”这是技能调用请求，**没有 `ff-spec retro` 或 `ff-spec rsi` 命令**。

复盘面向已发生的项目或工作流程事件，并不限定只能分析业务项目；用户可明确指定 FF 自身的一次真实执行作为对象。输出包含事件与来源、实际代价、已有机制、少量可证伪候选、最小补丁与撤销方式，最后给保留/撤销/暂缓及证据；没有值得做的候选也可以结束。候选本身不授予修改 FF 的权限。

现有[复盘技能](../../skills/ff-retro/SKILL.md)和[候选模板](../../skills/ff-retro/references/template.md)要求：已有批准范围覆盖才实施；用原失败样本与正常样本验证最小改动，再独立复核，失败则撤销自有改动。这是由执行者遵守的流程，不是自动实验引擎。

如果 RSI 指“递归自我改进”，当前尚无专用递归循环、自动创建 FF 改进分支、完整自动对照评估或自动晋级为默认版本的系统。一次用户发起的复盘可以提出改进 FF 的候选，但不会递归改写自己的技能、权限或批准记录，也不会自动合并、发布。本版补充了[用户发起的 FF 改进方法](../../skills/ff-retro/references/ff-improvement.md)：冻结旧版/失败及正常控制，隔离候选，独立审核后等待用户确认晋级；没有自动递归评估引擎。可把实际验证方法记为一个[资产候选](../../iterations/0.9.1/ASSET.md)，下次相关 Intake 只读核对，不自动复制、执行或上传私有内容。


## 技能索引

| 技能 | 什么时候用 | 主要输出或动作 |
| --- | --- | --- |
| [ff-intake](../../skills/ff-intake/SKILL.md) | 接手、恢复、状态不明 | 只读事实对账、有效/失效/未知项和下一职责 |
| [ff-grill](../../skills/ff-grill/SKILL.md) | 目标、范围或重要取舍不清 | 用户原意、目标、约束、候选与确认状态；按既有记录模式处理讨论 |
| [ff-spec](../../skills/ff-spec/SKILL.md) | 缺行为规格或获准变更需求 | 主要行为、边界、失败路径、验收及受影响范围 |
| [ff-design](../../skills/ff-design/SKILL.md) | 有视觉与交互未知 | 可评审设计候选、主要旅程、状态与视觉约束；需要真实用户选定的取舍保持候选 |
| [ff-prove](../../skills/ff-prove/SKILL.md) | 可行性或真实入口存在关键未知 | 有预算/停止条件的实验、实际观察、限制和建议 |
| [ff-plan](../../skills/ff-plan/SKILL.md) | 需要拆任务、依赖或重排 | 可独立验收的纵向切片、依赖和验证方式；只更新受影响工作 |
| [ff-implement](../../skills/ff-implement/SKILL.md) | 计划有效且任务已获准 | 实际实现、相关测试与变更证据；不代替独立审核 |
| [ff-review](../../skills/ff-review/SKILL.md) | 实施前审计划、实现后核对切片 | 计划、核心目标/主要流程、代码三类独立结论及缺口；小改可同一独立审核者覆盖适用项 |
| [ff-deliver](../../skills/ff-deliver/SKILL.md) | 阶段交付或用户验收准备 | 当前版本证据、偏差、未验证项、用户接受状态与授权范围内的交付 |
| [ff-diagnose](../../skills/ff-diagnose/SKILL.md) | 故障或性能回归根因不明 | 症状复现、竞争假设、因果证据和最小修复建议 |
| [ff-tdd](../../skills/ff-tdd/SKILL.md) | 实现中有可测试的业务行为 | 独立期望、真实调用链、实际 red → green 与相关回归 |
| [ff-handoff](../../skills/ff-handoff/SKILL.md) | 暂停、换会话或换执行者 | 当前版本/脏状态、已做/未做、运行中动作、证据和下一步的短检查点 |
| [ff-research](../../skills/ff-research/SKILL.md) | 需要回答具体事实疑问 | 带一手来源的事实、推论和待实测项，不自动启动开发 |
| [ff-retro](../../skills/ff-retro/SKILL.md) | 用户要求复盘已发生事件 | 基于真实代价的少量改进候选及保留/撤销/暂缓结论；不自动改变流程权限 |
| [ff-writing-fragments](../../skills/ff-writing-fragments/SKILL.md) | 需要采访和收集素材 | 经核对的素材片段、来源和待补缺口 |
| [ff-writing-shape](../../skills/ff-writing-shape/SKILL.md) | 已有素材，需要组织成文 | 文章结构与成稿，保留素材来源与未知项 |
| [ff-writing-beats](../../skills/ff-writing-beats/SKILL.md) | 希望按叙事节拍组织文章 | 节拍安排及对应文章内容；与 Shape 按需选一路 |

前九项是主职责，Diagnose / TDD / Handoff 是三个按需执行方法，后五项为独立可选方法。写作的 Shape 与 Beats 选一路即可；[可选方法示例](optional-methods.md)、[决策索引](decision-index.md)与[CodeGraph 适配器](codegraph.md)也按需选用，不增加必经阶段。扩展说明保留各自实验版本与限制。


## 自动检查与使用边界

| 层次 | 已提供的能力 | 仍需执行者/用户判断 |
| --- | --- | --- |
| 技能提示词 | 说明如何澄清、更新规格、只动受影响工作、审核、交接和保留未知 | AI 是否遵守、讨论是否明确批准、需求是否正确、设计是否适合；不是强制运行时隔离，不能保证绝不跑偏 |
| 三个只读 Python 检查器 | 确定性核对声明字段、版本/目标、所列文件与哈希，以及各自协议中的状态/顺序 | 来源是否真实、关键依赖是否漏列、独立审核是否真正独立；不会执行业务、浏览器操作或生成权限 |
| 项目本地 FF CLI | 在已有 OpenSpec/FF policy 配置下处理状态、指导、校验和生命周期门禁 | 记录的语义、业务结果和真实接受；`apply` 指导不等于执行，归档/合并/发布仍需各自授权 |

0.9 对 UI 截图只验 PNG 文件头、正尺寸和与轨迹绑定的路径/哈希，**不解码整图、不自动判断美观、不识别作者主动把旧像素伪称新截图**。静态 CodeGraph 只能提供结构线索。`RECORDED`、`SKIP_COMPLETED`、`OBSERVED` 都不能代替真人接受、来源真实性或 exactly-once 保证。
