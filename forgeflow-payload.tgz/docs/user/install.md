# 安装与首次使用

本页当前口径为 **0.11.0 源码候选**，共 **21 项技能**，支持 Codex、Claude Code 和 DSH。只在获准目标安装；不替换全局技能，不自动升级其他项目。以核对过的提交、manifest 和 payload 哈希确定实际安装内容，不以版本号代替证据。下方历史候选记录保留原版本范围，不代表本版已在全部宿主验收。

## 快速开始：Windows + Codex

基线 0.9.1 曾获准纳入 `work/061-through-09`，其[纳入回执](../../iterations/0.9.1/PROMOTION.md)不自动批准当前候选晋级或其他现用安装升级。先取得并核对选定版本的源码，把下面 `$Source` 改为源码根目录（其中有 `package.json` 和 `bin/ff-install.mjs`）。`$Project` 是你要使用 FF 的获准目标项目，两者可以不同。已有安装先盘点；[历史布局参考](../archive/installation/项目内安装指南.md)保留当时结构，当前重入/恢复操作以本页为准，不把同版本号的不同包哈希当作相同安装。

先准备 **Node.js >=20.19.0、npm、Git、tar**；三个可选只读检查器还需 **Python 3.9+**。full 构建需要访问 GitHub 和下载构建依赖。以下 PowerShell 示例把项目、外层 npm 缓存和临时目录放在 E 盘；旧项目请将 `$Project` 改为现有项目根目录。

```powershell
$Source = 'E:\tools\ForgeFlowSkill' # 已检出并核对的本仓库源码根目录
$Project = 'E:\projects\my-project'
$Cache = 'E:\forgeflow-cache'
New-Item -ItemType Directory -Force -Path $Project, "$Cache\tmp" | Out-Null
$env:TEMP = "$Cache\tmp"
$env:TMP = $env:TEMP
$env:npm_config_cache = "$Cache\npm"
node "$Source\bin\ff-install.mjs" install --project "$Project" --host codex --mode full --build
Set-Location $Project
node .forgeflow/install/doctor.mjs
node .forgeflow/ff-spec.mjs --help
```

`--build` 明确允许安装器构建本地 CLI。**未发布到 npm registry**；不要假定存在可直接安装的公开 FF npm 版本。原生 Windows full 构建/安装已在 0.8/0.9 冻结提交执行，具体版本与哈希见对应[版本与证据](../archive/README.md)。

安装内容位于项目的 `.forgeflow/` 与 `.agents/skills/`。所有宿主都会同时安装独立的 RSI 证据工具 `node .forgeflow/ff-rsi.mjs`（见 [FF RSI 证据工具](rsi.md)），以及可选的外部审查调用器 `node .forgeflow/ff-reviewer.mjs`（见 [可配置的外部独立审查](review-backends.md)；没有 `openspec/ff-review.json` 时不会调用任何后端）。RSI 只冻结/对照/记录，不激活版本。full 构建的内层缓存和临时数据仍在项目 `.forgeflow/install/` 下；上述外层设置不保证所有系统工具都不写项目外文件。工具源无需复制进每个项目，也不替换全局 OpenSpec。

只要技能、暂不需要 CLI 门禁：将 `--mode full --build` 改为 `--mode skills-only`。此模式的 doctor 和 CLI 会返回 **BLOCKED**。Claude Code 将宿主参数改为 `--host claude`，技能安装至 `.claude/skills/`，原生 ff-intake 仅有人工空白项目的[限定成功回执](../../iterations/0.9.3-dual-host.1/native-host-validation.md)，不代表所有技能或实际业务验收。CodeGraph 默认关闭。

## 在 DeepSeek Harness（DSH）中使用

DSH 的宿主参数是 `--host dsh`，技能安装至项目内的 `.dsh/skills/`（技能名与数量不变，仍为当前的 21 个 `ff-*` 目录）。DSH 按项目级优先读取技能目录，同一项目里 `.dsh/skills` 排在 `.agents/skills` 之前，因此 DSH 会加载 FF 副本，Codex 仍读取自己的 `.agents/skills`，互不覆盖。

```powershell
node "$Source\bin\ff-install.mjs" install --project "$Project" --host dsh --mode full --build
Set-Location $Project
node .forgeflow/install/doctor.mjs --host dsh
node .forgeflow/ff-spec.mjs status
node .forgeflow/ff-spec.mjs adopt            # 查看推断出的 policy
node .forgeflow/ff-spec.mjs adopt --write    # 落盘并预览每个活动 change
```

安装时会在每个 `SKILL.md` 追加宿主协作块：独立审查交给 `subagent`，`tasks.md` 是任务权威（`todo_write` 只做镜像），交付用 `present`，plan mode 下先 `exit_plan_mode` 再动手。`doctor --host dsh` 额外输出 `discovery`（实际发现的技能目录、数量、同项目内其他宿主根）与 `handshake`（技能版本、安装状态版本、CLI 报告的版本；CLI 版本由源版本派生）；三者不一致时指出是哪一侧过期，而不是笼统报 READY。

与 Codex 共用同一项目时用 `--hosts dsh,codex`；只给 DSH 用时保持单宿主，避免为另一宿主重复维护技能副本。没有 `openspec/ff-policy.json` 时 `archive` 会打印 `⚠ FF gates disabled` 而不是静默通过，`FF_ALLOW_UNGATED=1` 可关闭该提示。

## DSH 原生插件（可选，需重启）

`--host dsh` 的安装会把可选的 DSH 插件复制到项目 `.forgeflow/dsh-plugin/`：两个只读工具 `ff_status`/`ff_gate`、`/ff-status` 命令、注册到 `systemPrompt` 的四层失效常驻锚点、`ff-spec.mjs archive` 的本地守卫，以及左侧栏的只读 "ForgeFlow 看板"（需求/架构参考/模块/任务进度）。插件零外部依赖，不替代 FF CLI。注册到某个 DSH profile 后需**重启 DSH** 才生效：

```powershell
# 推荐：全局安装（物化到 %USERPROFILE%\.dsh\plugins\forgeflow-dsh，所有工作区共用）
node .forgeflow/dsh-plugin/register.mjs --global
# 撤销注册（保留全局副本）；加 --purge 连副本一起删除
node .forgeflow/dsh-plugin/register.mjs --remove --global
# 仅本项目：link 指向该插件目录（不带 --global）
node .forgeflow/dsh-plugin/register.mjs --profile "$env:USERPROFILE\.dsh\profiles\desktop"
```

`--global` 会先把插件的 7 个运行文件物化到 `<DSH_HOME>/plugins/forgeflow-dsh`（`DSH_HOME` 默认 `%USERPROFILE%\.dsh`，可用 `--home` 覆盖），profile 的 link 只指向这个稳定副本；因此项目目录被移动或删除时，其他工作区的插件不会再加载失败。物化逐文件按字节比较，只在缺失或内容不同时写入，重复执行返回空 `changed`；旧版本指向项目目录的 FF 插件链接会被自动替换，外来目录仍拒绝覆盖。

注册会写该 profile 的 `package.json`（`link:` 依赖与 `dsh.profile.bundles`）、`cordis.patch.yml`（`forgeflow-dsh` id 的注册块），并建立 `node_modules/@local/forgeflow-dsh` 目录链接（Windows 为 junction）；`package.json` 与 `cordis.patch.yml` 写前生成 `*.bak-<时间戳>` 备份。重复执行不会重复写入，缺少 profile 时退出码 2。`doctor --host dsh` 只报告项目内插件副本是否存在（`plugin.available`/`plugin.path`，以及 `plugin.client`/`plugin.generator`），不读取全局 profile。

看板读取项目根的 `.forgeflow/board.json` 快照；快照由插件自带的生成器手动生成（加 `--write` 才落盘，内容不变不重写）：

```powershell
node .forgeflow/dsh-plugin/generate-board.mjs --write
```

数据来自 `planning/intent-view-links.json`（或 `source/planning/...`）；任务进度只在存在 `openspec/changes/*/tasks.md` 时统计代码围栏外的 `[x]`/`[ ]`，没有 OpenSpec 时显示"权威进度未知"。架构区只列参考文档，不声称已有结构化架构模型。面板只读，更新快照后点"刷新"即可，不需要重启。

边界（best-effort）：守卫按 shell 引号切词，只把**命令位置**上由 `node`/`npx` 执行的 `.forgeflow/ff-spec.mjs archive` 当作目标（`echo`、引号文本里的同名子串不算，`build` 不再匹配）；`-h`/`--help` 与 `--ff-disposition canceled|rejected` 是只读或回滚式收尾，直接放行。命中且在磁盘上找到时先运行 `status --json`，门禁 `blocked` 或 policy `invalid` 才拒绝。`run_code` 等不透明调用、变量拼出的命令或其他入口无法拦截，最终仍以 FF CLI 自身门禁为准。`enabled: false` 或 `FF_ALLOW_UNGATED=1` 可关闭拦截；`anchor: false` 关闭常驻锚点；skills-only 安装没有 CLI 门禁，工具会明确报告 BLOCKED/disabled。

## 同一项目同时供 Codex 和 Claude 使用

把单数 `--host codex` 改为显式的 `--hosts codex,claude`。目标项目已有单端安装时，同一命令迁移到双端；顺序 `claude,codex` 也可。每端仍各有 21 项技能，不是 42 个不同技能。

```powershell
node "$Source\bin\ff-install.mjs" install --project "$Project" --hosts codex,claude --mode full --build
node "$Source\bin\ff-install.mjs" doctor --project "$Project" --host codex
node "$Source\bin\ff-install.mjs" doctor --project "$Project" --host claude
# 在目标项目根目录也可独立自检，无需保留安装器源码：
node .forgeflow/install/doctor.mjs --host codex
node .forgeflow/install/doctor.mjs --host claude
```

Codex 读取 `.agents/skills/ff-*`，Claude 读取 `.claude/skills/ff-*`；两端绑定同一 `.forgeflow/ff-spec.mjs`、版本、manifest、模式和 release。`doctor --host` 检查指定端托管文件、共同依赖和真实 CLI 探测；省略宿主检查全部。另一端普通文件损坏不会伪装成所选端损坏，但共同文件、路径或状态异常仍会阻止。**READY 证明文件与 CLI 可用，不证明宿主模型已经加载/调用技能，也不证明业务或真人验收。** 后续独立模型试验中 Claude 限定 ff-intake 成功、Codex 原读取受策略阻塞；二者不由 doctor 状态推导。

双端升级继续用 `--hosts codex,claude`；单数参数会阻止意外删掉另一端。旧 schema 1 单端安装保留旧参数和单端切换语义；双端迁移使用 schema 2，移除一端后仍是 schema 2。两端不能混用不同版本或 full/skills-only 模式；两种模式之间可显式重装，full 仍需 `--build`。同版本、同 manifest、同宿主集合及同模式重入不改状态字节。

只移除一端，例如保留 Codex：

```powershell
node "$Source\bin\ff-install.mjs" remove-host --project "$Project" --host claude
node "$Source\bin\ff-install.mjs" doctor --project "$Project" --host codex
```

只删除该端有哈希记录的文件，不递归删除技能目录；其中用户额外文件、另一端和共享运行时保持。已移除端重复移除返回 `UNCHANGED`；拒绝删除最后一端，本轮没有完整卸载器。重新添加仍用 `--hosts codex,claude`。新增端已有未托管同名文件，或任一端托管文件/共享运行时有用户改动时，安装、移除和回滚都会阻止并保留现场，不覆盖文件。

```mermaid
flowchart LR
  A[旧单端 schema 1] -->|显式 --hosts| B[双端 schema 2]
  B -->|remove-host| C[单端 schema 2]
  C -->|显式 --hosts| B
  B --> D[共享固定运行时]
  D --> E[doctor --host codex]
  D --> F[doctor --host claude]
```

`rollback` 回退前一整笔项目安装：宿主集合、版本、模式一起恢复；它不是仅回退所选端。`recover` 也处理整笔事务。不要同时运行两个安装器；文件就绪不提供两个模型并发修改业务文件的协调机制。

## 当前验证边界

技能/安装包版本为 **0.11.0**；本源码的 full 构建将 FF CLI 版本派生为 **0.11.0**，不是历史 adapter 版本号。skills-only 没有可用的 full CLI，不能据此要求版本输出成功。Goal 原生写入与状态同步未实现；使用与实验边界见[Codex Goal](codex-goal.md)，0.10 基线引入只读[目标进度](goal-progress.md)。0.10 基线验证范围和未测项见[源码候选回执](../../iterations/0.10.0/README.md)；后续增量仍须核对自身提交及证据，不能直接继承全部通过结论。

安装与证据按完整提交、manifest 和 payload 哈希区分，不能只看版本号。0.9.2-goal.2 已有实际 Windows/Codex 隔离项目 full 构建、安装及 doctor READY；skills-only 的 doctor 为预期 BLOCKED。选定桌面后端的技能加载/调用已有有界观察，包与提交、后续文档包的继承理由见[原生验证与证据继承](../../iterations/0.9.2-goal.2/native-closeout.md)。这些不是全平台或产品真人验收。

历史失败仍保留：71d0464 原候选有 full 构建/CLI 记录；46022d7 文档包两次 full 构建因 npm TLS 下载失败，仅 skills-only 新包安装/Health 入口通过。此前成功不自动覆盖其他包；旧 PATH CLI 的 Codex setup refresh 故障不能概括为当前所有桌面后端均失败。Claude 当前仅有上述有界原生 ff-intake 结果；两端完整模型工作流、全平台与产品真人验收仍未证明。

仅需技能时用 `--mode skills-only`，不要同时加 `--build`。成功状态是 `INSTALLED_SKILLS_ONLY_GATES_BLOCKED`，不是 full READY；21 项技能可分发，FF CLI 门禁不可用。full 依赖网络下载固定构建依赖，不修改锁文件、TLS 或权限来绕过失败。

安装路径是目标项目的 `.agents/skills/`（Codex）或 `.claude/skills/`（Claude），控制与运行目录在 `.forgeflow/`。外层 npm cache/TEMP 可放 E 盘，full 内层缓存仍在目标项目；不承诺所有系统工具完全不写其他位置。

## 重入、回滚与恢复

同一 host/mode/manifest 可返回 `UNCHANGED`；同版本号不同包哈希不代表相同安装。已有安装先盘点并保存用户修改，不手工覆盖技能目录。维护命令从已核对源码运行，`$Project` 为实际目标项目：

```powershell
node "$Source\installer.mjs" doctor --project "$Project"
node "$Source\installer.mjs" rollback --project "$Project"
node "$Source\installer.mjs" recover --project "$Project"
```

后两项会改变安装状态，只在已有相应授权、无运行中的安装且核对诊断后使用；有 lock/pending 或部分输出先检查，不盲重试或删除现场。旧说明的实现细节保留在[历史安装资料](../archive/README.md#历史安装资料)，不作为本版已验收承诺。

安装后的使用请求、实际 CLI/Python 入口见[能力与使用场景](capabilities.md)。源码构建、打包与验证见[开发维护](../maintainers/development.md)。本仓库没有已发布 npm 包，不把历史 npx 指令或浮动 main 当当前工作分支安装来源。


doctor 是只读检查。安装器异常退出后，先确认对应安装进程已结束，再仅移除其**空的** `.forgeflow/install/lock` 目录，运行 recover；不要删除 pending、backup 或整个安装目录。提交前中断返回 `RECOVERED` 并恢复原托管文件；state 已原子提交则核对最终文件与状态后返回 `COMMITTED`。有后续用户改动会保留 pending 并报冲突，须明确处理冲突再恢复；它不提供磁盘断电级原子性保证。

## 历史演进记录（各节仅对应所标版本）

以下保留旧候选的技能数量和验证依据，不覆盖上文 0.11.0 / 21 项技能的当前口径。

### 试点候选：离线复用与 worktree
0.9.4-trial.1 为本地候选，未升级现有项目或全局安装。已有同一源 pin 的完整构建时，可显式复用该 `tools/openspec` 目录，避免重新联网：

```powershell
node installer.mjs install --project E:\work\my-worktree --hosts codex,claude --mode full --reuse-build E:\work\verified-source\tools\openspec
```

该路径内须有 upstream.json 与已验证 .build（包括依赖）；源 pin、marker 和运行时文件哈希都要匹配。也可选择已有项目 `.forgeflow/install/releases/<release>/tools/openspec`。复用仍复制本地运行时，未实现共享缓存或承诺减少磁盘占用；各项目的状态/配置/证据完全隔离。`--reuse-build` 与 `--build` 互斥，技能专用模式不可用。launcher 以当前项目为目标，遇到未安装的 Git worktree 边界会阻塞并提示在该 worktree 安装，不会写主 checkout。

安装结果含 gitGuidance，精确列运行时、launcher 和每个 FF 技能目录，供用户选择 ignore 或 vendor；不会改 `.gitignore`。不要忽略整个 `.forgeflow`。版本控制 policy、稳定计划/进度、回执、审核证据和精确 LF 属性；安装生成物与业务配置分开处理。doctor 的 runtime READY 只说明程序可运行，gates 的 UNCONFIGURED/NO_CHECKS/INVALID 均不能当作门禁通过。普通回执操作见[生命周期 v2](../maintainers/SPEC-LIFECYCLE.md)。

### 0.9.6-architecture.1 源码候选增量

该候选将独立 `ff-architecture-review` 纳入原技能分发机制，共18项，保留旧17项安装记录读取/回滚边界。既有 full/skills-only、Codex/Claude 目录及权限模式不变，不新增 FF CLI 子命令或安全门禁。当前规则与使用方式见[可选架构评估](architecture-review.md)；前面的0.9.3验证回执仍只对应其原版本。

本轮只在 E 盘临时 fixture 做 skills-only 分发验证，不升级真实安装、不重建 full 运行时。文件已分发与宿主原生发现/加载是两种事实；后者尚未验证，不声称用户当前宿主已有该命令。

### 0.9.6-derivation.1 源码候选增量

保留18项技能和既有安装机制，只在 ff-spec 增加[可选架构推导](architecture-derivation.md)的条件入口及本地参考，ff-design保留短推荐指引。没有新增宿主命令或运行时策略引擎，安装状态schema及CLI不变。本轮源码候选不更新真实全局/项目安装；用户使用已安装旧候选时不能假定新增方法已加载。

### 0.9.6-derivation.2 源码候选增量

独立 `ff-architecture-derive` 通过既有Codex/Claude技能目录分发，共19项技能，唯一推导模板迁至新技能本地；ff-spec只推荐并引用成果。状态读取保留旧17/18与新19完整清单兼容，隔离fixture验证迁移和回滚，不自动更新真实安装。没有新FF CLI子命令或full运行时构建。文件分发与原生加载、真实用户验收仍是不同事实；真实安装更新以单独授权及该目标的安装回执为准。

### 0.9.6-derivation.3 源码候选增量

保持19项技能、安装机制和运行时不变，仅修正架构推导的关键结构完成判据及使用说明。旧derivation.2现场草案与本轮同输入首次输出对照分别留存，合成行为和分发检查不代表原生加载或业务验收。没有更新source、DH或全局真实安装；需要另行授权才能升级。architecture-review的评估规则未改（包metadata版本同步），两入口仍独立可选。

### 0.9.6-derivation.4 源码候选增量

保留derivation.3推导修复和19技能，给architecture-review的现有按需参考补充按决策范围判断颗粒度的短规则。安装/运行时机制未变，没有更新真实安装；显式读技能的合成执行与原生加载、用户验收分别记录。

### 独立图示候选（2026-10-30）

新增 `ff-diagram` 后本候选共20技能；安装器保留旧17/18/19完整清单读取，当前新装为20。技能本地含全部按需参考，可单独复制该目录使用，不依赖其他FF技能或仓库docs路径。四个相关旧入口仅名称推荐；未安装新技能不阻断原有独立工作。候选仍未发布，本轮不更新用户实际安装；skills-only分发通过不等于full门禁可用或宿主已实际加载。

已安装且已有ff-diagram的项目，可用本候选新增[单技能更新](update-skill.md)仅升级该元能力；原运行时、其他技能与回执保留。旧17/18/19清单首次加入仍须显式完整迁移，不承诺该迁移不动其他文件。
